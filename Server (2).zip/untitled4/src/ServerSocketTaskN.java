import java.io.*;
import java.net.*;
import java.util.Date;
import java.util.List;

public class ServerSocketTaskN {
    private static NoteManagement noteManagement = new NoteManagement();

    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(12345);
            System.out.println("Server is listening on port 12345...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected: " + clientSocket.getInetAddress().getHostAddress());
                // Обробка клієнта в окремому потоці
                new ClientHandler(clientSocket).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class ClientHandler extends Thread {
        private Socket clientSocket;
        private ObjectOutputStream objectOutputStream;
        private ObjectInputStream objectInputStream;

        public ClientHandler(Socket socket) {
            this.clientSocket = socket;
            try {
                this.objectOutputStream = new ObjectOutputStream(clientSocket.getOutputStream());
                this.objectInputStream = new ObjectInputStream(clientSocket.getInputStream());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void run() {
            try {
                String request;
                while((request = (String) objectInputStream.readObject()) != null){
                    System.out.println(request);

                    switch (request) {
                        case "CREATE":
                            Note note = (Note) objectInputStream.readObject();
                            noteManagement.addNote(note);
                            System.out.println("Create");
                            break;

                        case "READ":
                            System.out.println("read");
                            objectOutputStream.writeObject(noteManagement.getNotes());
                            break;

                        case "SEARCH":
                            List<Note> search = noteManagement.searchNotes((String) objectInputStream.readObject());
                            objectOutputStream.writeObject(search);
                            break;

                        case "FILTER_BY_DATE":
                            Date startDate = (Date) objectInputStream.readObject();
                            Date endDate = (Date) objectInputStream.readObject();
                            List<Note> filteredByDate = noteManagement.filterNotesByDate(startDate, endDate);
                            objectOutputStream.writeObject(filteredByDate);
                            break;
                        case "FILTER_BY_TAG":
                            String tag = (String) objectInputStream.readObject();
                            List<Note> filteredByTag = noteManagement.filterNotesByTag(tag);
                            objectOutputStream.writeObject(filteredByTag);
                            break;

                        case "SORT_BY_IMPORTANCE":
                            List<Note> sortedByImportance = noteManagement.sortNotesByImportance();
                            objectOutputStream.writeObject(sortedByImportance);
                            break;
                        case "DELETE":
                            String titleToDelete = (String) objectInputStream.readObject();
                            noteManagement.deleteNote(titleToDelete);
                            objectOutputStream.writeObject("Note deleted successfully");
                            break;

                        default:
                            objectOutputStream.writeObject("Invalid action");
                    }
                }
                clientSocket.close();

            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }


        private void delete(String title) throws IOException {
            noteManagement.deleteNote(title);
            objectOutputStream.writeObject("Note deleted successfully");
        }


    }

}
