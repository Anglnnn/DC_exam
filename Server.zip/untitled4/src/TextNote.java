import java.util.List;

// Клас для текстових нотаток
public class TextNote extends Note {
    public TextNote(String title, String content, int importance, List<String> tags) {
        super(title, content, importance, tags);
    }

    @Override
    public String getType() {
        return "Text";
    }
}
