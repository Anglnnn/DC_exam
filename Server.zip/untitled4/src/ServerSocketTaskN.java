public class ServerSocketTaskN {

}
