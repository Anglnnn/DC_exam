import java.util.*;
import java.util.stream.Collectors;

public class NoteManagement {
    private List<Note> notes;
    public NoteManagement() {
        this.notes = new ArrayList<>();
    }
    public List<Note> getNotes() {
        return notes;
    }

    public void addNote(Note note) {
        notes.add(note);
    }

    public void deleteNote(String title) {
        notes.removeIf(note -> note.getTitle().equals(title));
    }
    public List<Note> searchNotes(String searchTerm) {
        return notes.stream()
                .filter(note -> note.getContent().contains(searchTerm) || note.getTitle().contains(searchTerm))
                .collect(Collectors.toList());
    }

    public List<Note> filterNotesByDate(Date startDate, Date endDate) {
        return notes.stream()
                .filter(note -> note.getLastModified().after(startDate) && note.getLastModified().before(endDate))
                .collect(Collectors.toList());
    }

    public List<Note> filterNotesByTag(String tag) {
        return notes.stream()
                .filter(note -> note.getTags().contains(tag))
                .collect(Collectors.toList());
    }

    public List<Note> sortNotesByLastModified() {
        List<Note> sortedNotes = new ArrayList<>(notes);
        Collections.sort(sortedNotes, Comparator.comparing(Note::getLastModified).reversed());
        return sortedNotes;
    }

    public List<Note> sortNotesByImportance() {
        List<Note> sortedNotes = new ArrayList<>(notes);
        Collections.sort(sortedNotes, Comparator.comparingInt(Note::getImportance).reversed());
        return sortedNotes;
    }

    public List<Note> sortNotesByTitle() {
        List<Note> sortedNotes = new ArrayList<>(notes);
        Collections.sort(sortedNotes, Comparator.comparing(Note::getTitle));
        return sortedNotes;
    }
}
