import java.io.Serializable;
import java.util.Date;
import java.util.List;

public abstract class Note implements Serializable {
    private static final long serialVersionUID = 1L;

    private String title;
    private String content;
    private Date lastModified;
    private int importance;
    private List<String> tags;

    public Note(String title, String content, int importance, List<String> tags) {
        this.title = title;
        this.content = content;
        this.importance = importance;
        this.tags = tags;
        this.lastModified = new Date(); // Початковий час створення
    }

    // Конструктор, гетери, сетери та інші методи

    public abstract String getType(); // Метод для отримання типу нотатки

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public Date getLastModified() {
        return lastModified;
    }

    public int getImportance() {
        return importance;
    }

    public List<String> getTags() {
        return tags;
    }
}

