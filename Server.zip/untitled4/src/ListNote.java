import java.util.List;

// Клас для нотаток у вигляді списку
public class ListNote extends Note {
    private String[] listItems;

    public ListNote(String title, String content, int importance, List<String> tags) {
        super(title, content, importance, tags);
    }

    // Конструктор, гетери, сетери та інші методи

    @Override
    public String getType() {
        return "List";
    }
}
