import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class NoteServiceImpl extends UnicastRemoteObject implements NoteManagement{
    private List<Note> notes;

    public NoteServiceImpl() throws RemoteException {
        super();
        this.notes = new ArrayList<>();
    }

    @Override
    public void createNote(Note note) throws RemoteException {
        notes.add(note);
    }

    @Override
    public List<Note> getNotes() throws RemoteException {
        return notes;
    }

    @Override
    public List<Note> searchNotes(String searchTerm) throws RemoteException {
        List<Note> foundNotes = new ArrayList<>();
        for (Note note : notes) {
            if (note.getTitle().contains(searchTerm) || note.getContent().contains(searchTerm)) {
                foundNotes.add(note);
            }
        }
        return foundNotes;
    }

    @Override
    public void updateNote(String title, Note updatedNote) throws RemoteException {
        Iterator<Note> iterator = notes.iterator();
        while (iterator.hasNext()) {
            Note note = iterator.next();
            if (note.getTitle().equals(title)) {
                iterator.remove();
                notes.add(updatedNote);
                break;
            }
        }
    }

    @Override
    public void deleteNoteByTitle(String title) throws RemoteException {
        notes.removeIf(note -> note.getTitle().equals(title));
    }
}
