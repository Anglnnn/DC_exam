import java.io.*;
import java.net.Socket;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // Клієнт
        try (
                Socket socket = new Socket("localhost", 12345);
                ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                ObjectInputStream in = new ObjectInputStream(socket.getInputStream())
        ) {
            while(true){
                int n = scanner.nextInt();
                switch (n){
                    case 1:
                        out.writeObject("CREATE");
                        Note newNote = new TextNote("New Note", "Content", 2, List.of("tag1", "tag2"));
                        out.writeObject(newNote);
                        break;
                    case 2:
                        out.writeObject("READ");
                        Object allNotes = in.readObject();
                        System.out.println("All Notes: " + allNotes);
                        break;
                }
            }

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

}