import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface NoteManagement extends Remote {
    void createNote(Note note) throws RemoteException;

    List<Note> getNotes() throws RemoteException;

    List<Note> searchNotes(String searchTerm) throws RemoteException;

    void updateNote(String title, Note updatedNote) throws RemoteException;

    void deleteNoteByTitle(String title) throws RemoteException;
}
