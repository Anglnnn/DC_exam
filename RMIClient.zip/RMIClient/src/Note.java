import java.io.Serializable;
import java.util.Date;
import java.util.List;

public abstract class Note implements Serializable {
    private static final long serialVersionUID = 1L;
    private String title;
    private String content;
    private Date lastModified;
    private int importance;
    private List<String> tags;

    public Note(String title, String content, int importance, List<String> tags) {
        this.title = title;
        this.content = content;
        this.importance = importance;
        this.tags = tags;
        this.lastModified = new Date(); // Початковий час створення
    }

    // Конструктор, гетери, сетери та інші методи

    public abstract String getType(); // Метод для отримання типу нотатки

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public Date getLastModified() {
        return lastModified;
    }

    public int getImportance() {
        return importance;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setLastModified(Date lastModified) {
        this.lastModified = lastModified;
    }

    public void setImportance(int importance) {
        this.importance = importance;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    @Override
    public String toString() {
        return "Note{" +
                "title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", lastModified=" + lastModified +
                ", importance=" + importance +
                ", tags=" + tags +
                '}';
    }
}


