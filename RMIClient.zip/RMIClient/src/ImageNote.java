import java.util.List;

// Клас для нотаток із зображенням
public class ImageNote extends Note {
    private String imagePath;

    public ImageNote(String title, String content, int importance, List<String> tags) {
        super(title, content, importance, tags);
    }

    // Конструктор, гетери, сетери та інші методи

    @Override
    public String getType() {
        return "Image";
    }
}
