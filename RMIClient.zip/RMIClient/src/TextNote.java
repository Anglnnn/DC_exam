import java.util.Date;
import java.util.List;

// Клас для текстових нотаток
public class TextNote extends Note {
    private static final long serialVersionUID = 123456789L;

    public TextNote(String title, String content, Date date, int importance, List<String> tags) {
        super(title, content, importance, tags);
    }

    @Override
    public String getType() {
        return "Text";
    }
    public void update(String newContent, int newImportance, List<String> newTags) {
        this.setContent(newContent);
        this.setImportance(newImportance);
        this.setTags(newTags);
    }

}
