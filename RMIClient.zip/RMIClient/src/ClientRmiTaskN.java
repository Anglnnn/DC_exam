import java.rmi.Naming;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class ClientRmiTaskN {
    public static void main(String[] args) {
        try {
            NoteManagement noteService = (NoteManagement) Naming.lookup("rmi://localhost/NoteService");

            Scanner scanner = new Scanner(System.in);

            // Опції для користувача
            while (true){
                System.out.println("1. Create\n2. Read\n3. Update\n4. Delete\n5. Search\n6. Exit");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1: // Create
                        System.out.println("Enter note title:");
                        String title = scanner.next();
                        System.out.println("Enter note content:");
                        String content = scanner.next();
                        Note newNote = new TextNote("New Note", "Content", new Date(2000,1,12), 2, List.of("tag1", "tag2"));
                        noteService.createNote(newNote);
                        System.out.println("Note created successfully.");
                        break;

                    case 2: // Read
                        List<Note> notes = noteService.getNotes();
                        System.out.println("All notes: " + notes);
                        break;
                    case 3: // Update
                        System.out.println("Enter note title to update:");
                        String updateTitle = scanner.next();

                        // Здійсніть запит до сервера для отримання екземпляра Note за назвою
                        List<Note> notesToUpdate = noteService.searchNotes(updateTitle);

                        if (!notesToUpdate.isEmpty()) {
                            // Обирайте перший екземпляр, якщо є кілька результатів
                            Note noteToUpdate = notesToUpdate.get(0);

                            // Припустимо, що є метод update в TextNote (можна розширити для інших типів нотаток)
                            if (noteToUpdate instanceof TextNote) {
                                TextNote textNoteToUpdate = (TextNote) noteToUpdate;
                                System.out.println("Enter new content for the note:");
                                String newContent = scanner.next();
                                textNoteToUpdate.update(newContent, textNoteToUpdate.getImportance(), textNoteToUpdate.getTags());

                                // Викликайте метод оновлення на сервері
                                noteService.updateNote(updateTitle, textNoteToUpdate);

                                System.out.println("Note updated successfully.");
                            } else {
                                System.out.println("Cannot update notes of this type.");
                            }
                        } else {
                            System.out.println("Note not found.");
                        }
                        break;
                    case 4: // Delete
                        System.out.println("Enter note title to delete:");
                        String deleteTitle = scanner.next();
                        noteService.deleteNoteByTitle(deleteTitle);
                        System.out.println("Note deleted successfully.");
                        break;

                    case 5: // Search
                        System.out.println("Enter search term:");
                        String searchTerm = scanner.next();
                        List<Note> searchResults = noteService.searchNotes(searchTerm);
                        System.out.println("Search results: " + searchResults);
                        break;

                    case 6: // Exit
                        System.out.println("Exiting client application.");
                        System.exit(0);
                        break;

                    default:
                        System.out.println("Invalid choice.");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}