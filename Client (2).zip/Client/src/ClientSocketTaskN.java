import java.io.*;
import java.net.Socket;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class ClientSocketTaskN {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // Клієнт
        try (
                Socket socket = new Socket("localhost", 12345);
                ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                ObjectInputStream in = new ObjectInputStream(socket.getInputStream())
        ) {
            while(true){
                System.out.println("1.Create \n2.READ \n3.SEARCH \n4.FILTER_BY_DATE \n" +
                        "5.FILTER_BY_TAG \n6.SORT_BY_IMPORTANCE \n7.DELETE\n");
                int n = scanner.nextInt();
                switch (n){
                    case 1:
                        out.writeObject("CREATE");
                        Note newNote = new TextNote("New Note", "Content", new Date(2000,1,12), 2, List.of("tag1", "tag2"));
                        out.writeObject(newNote);
                        break;
                    case 2:
                        out.writeObject("READ");
                        List<Note> allNotes = (List<Note>)in.readObject();
                        System.out.println("All Notes: " + allNotes.toString());
                        break;
                    case 3:
                        out.writeObject("SEARCH");
                        out.writeObject("Content");
                        List<Note> search = (List<Note>)in.readObject();
                        System.out.println("Search: " + search.toString());
                        break;
                    case 4:
                        out.writeObject("FILTER_BY_DATE");
                        System.out.println("Enter start date (in milliseconds):");
                        long startDate = scanner.nextLong();
                        System.out.println("Enter end date (in milliseconds):");
                        long endDate = scanner.nextLong();
                        out.writeObject(new Date(startDate));
                        out.writeObject(new Date(endDate));
                        List<Note> filteredByDate = (List<Note>) in.readObject();
                        System.out.println("Filtered by date: " + filteredByDate.toString());
                        break;
                    case 5:
                        out.writeObject("FILTER_BY_TAG");
                        System.out.println("Enter tag:");
                        String tag = scanner.next();
                        out.writeObject(tag);
                        List<Note> filteredByTag = (List<Note>) in.readObject();
                        System.out.println("Filtered by tag: " + filteredByTag.toString());
                        break;
                    case 6:
                        out.writeObject("SORT_BY_IMPORTANCE");
                        List<Note> sortedByImportance = (List<Note>) in.readObject();
                        System.out.println("Sorted by importance: " + sortedByImportance.toString());
                        break;
                    case 7:
                        out.writeObject("DELETE");
                        System.out.println("Enter note title to delete:");
                        String titleToDelete = scanner.next();
                        out.writeObject(titleToDelete);
                        String deleteResponse = (String) in.readObject();
                        System.out.println(deleteResponse);
                        break;

                }
            }

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

}