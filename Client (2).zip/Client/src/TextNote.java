import java.util.Date;
import java.util.List;

// Клас для текстових нотаток
public class TextNote extends Note {


    public TextNote(String title, String content, Date lastModified, int importance, List<String> tags) {
        super(title, content, lastModified, importance, tags);
    }

    @Override
    public String getType() {
        return "Text";
    }
}
